package components;

import java.util.List;

public class Flower {
    Double price;
    String type;
    List<Flower> flowerArray;

    public Flower(Double price, String type, List<Flower> flowerArray) {
        this.price = price;
        this.type = type;
        this.flowerArray = flowerArray;
    }
}
