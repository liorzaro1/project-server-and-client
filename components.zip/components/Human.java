package components;

import java.util.ArrayList;
import java.util.concurrent.CompletionService;

public class Human implements Comparable<Human> {
    private static long idCounter = 0;  // static data member

    // data members
    private String name; // default value = null
    private double age; // default value = 0.0
    private long id;   //  default value = 0L

    // methods
    // constructor is a special method that initializes newly created objects

    public Human(String name, double age) {
//        assert(name!=null);
//        this.name= name;
        if(name!=null) this.name = name;
        if(age >=0 && age <=130) this.age = age;
        this.id = ++idCounter;
    }

    // overloaded constructor
    public Human(String name){
        this(name,0);
        System.out.println("Invoked from second constructor");
    }

    public String getName() {
        return this.name;
    }

    public double getAge() {
        return age;
    }

    public long getId() {
        return id;
    }


    @Override
    public String toString() {
        return "(Name = " + name + ", Age = " + age + ")";
    }


    /**
     * equality between all data members (id excluded)
     * @param obj
     * @return
     */
    @Override
    public boolean equals(Object obj) {
        if(obj==null) return false;
        if(this==obj) return true;
        if(this.getClass()!=obj.getClass()) return false;
        // this and obj are of the same runtime class (both are Human)
        Human objAsHuman = (Human)obj;
        return this.name.equals(objAsHuman.name) && this.age == objAsHuman.age;
    }

    @Override
    public int compareTo(Human o) {
        if(this.age < o.age) return -1;
        if(this.age > o.age) return 1;
        // ages are equal
        if(this.name.length() > o.name.length()) return 1;
        if(this.name.length() < o.name.length()) return -1;
        return 0;
    }

    //main method is the entry point of our program
    public static void main(String[] args) {

        Human yossi1 = new Human("Yossi Levi",30.5);
        Human yossi2 = new Human("Yossi Levi", 30.5);
        Flower rose = new Flower(30.0,"Roses", new ArrayList<>());
        System.out.println(yossi1.equals(rose)); // false
        System.out.println(yossi1==yossi2); // false. address comparison
        System.out.println(yossi1.equals(null)); // false
        System.out.println(yossi1.equals(yossi1)); // true

        Human alex = new Human("Alex Cohen");
        System.out.println(alex);
        /*
        1. Java allocates memory in Heap for the new object (it has an address)
        2. data members are created and initialized to default values
        3. constructor invocation. called line by line (sequentially)
        4. new expression gets its value - address in memory
        5. variables is assigned with Right value
         */
        System.out.println(yossi1); // components.Human@AddressInMemoryInHex
        System.out.println(yossi1.getAge());
        System.out.println(yossi1.getId());


        String name; // default value = garbage value
        int number; // default value = garbage value

        Human shoshi = new Human("Shoshana Levi",22);
        Human dorit = new Human("Dorit Wolf", 60.5);
        Human dorit2 = new Human("Dorit tovi", 60.5);
        Human dorit3 = new Human("Dorit tovi", 60.5);

        System.out.println(shoshi.compareTo(dorit)); // expected -1
        System.out.println(dorit.compareTo(shoshi)); // expected 1
        System.out.println(dorit2.compareTo(dorit3)); // expected 0







    }
}
